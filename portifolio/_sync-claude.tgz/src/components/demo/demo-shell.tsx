"use client";

import { useEffect, useState } from "react";
import { LayoutTemplate, ServerCog } from "lucide-react";
import { Wallpaper } from "@/components/fx/wallpaper";
import { BackEndPanel } from "./back-end-panel";
import { FrontEndPanel } from "./front-end-panel";

type Lado = "front-end" | "back-end";

const lados: { id: Lado; titulo: string; texto: string; Icone: typeof ServerCog }[] = [
  {
    id: "front-end",
    titulo: "Front-end",
    texto: "Componentes de interface com animação, acessibilidade e estado.",
    Icone: LayoutTemplate,
  },
  {
    id: "back-end",
    titulo: "Back-end",
    texto: "Arquitetura, filas, contêineres, testes e deploy.",
    Icone: ServerCog,
  },
];

/** Página Dev: o visitante escolhe ver o front-end ou o back-end. A escolha fica no endereço (#front-end ou #back-end). */
export function DemoShell() {
  const [lado, setLado] = useState<Lado>("front-end");

  useEffect(() => {
    const ler = () => {
      const h = window.location.hash.replace("#", "");
      if (h === "front-end" || h === "back-end") setLado(h);
    };
    ler();
    window.addEventListener("hashchange", ler);
    return () => window.removeEventListener("hashchange", ler);
  }, []);

  function escolher(id: Lado) {
    setLado(id);
    window.history.replaceState(null, "", `#${id}`);
  }

  return (
    <>
      <section className="relative overflow-hidden pt-28 pb-20 text-center sm:pt-36 sm:pb-24">
        <Wallpaper variant="hero" fade="bottom" />
        <div className="wrap relative z-10 flex flex-col items-center gap-6">
          <h1 className="display-1">Dev.</h1>
          <p className="lead max-w-[640px]">
            Escolha um lado e veja na prática como eu trabalho: as interfaces que construo e as decisões de arquitetura por trás
            delas.
          </p>
          <div role="tablist" aria-label="Escolha o lado" className="mt-4 grid w-full max-w-[720px] gap-3 sm:grid-cols-2">
            {lados.map(({ id, titulo, texto, Icone }) => {
              const ativo = lado === id;
              return (
                <button
                  key={id}
                  role="tab"
                  type="button"
                  id={`aba-${id}`}
                  aria-selected={ativo}
                  aria-controls={`painel-${id}`}
                  onClick={() => escolher(id)}
                  className={`group flex items-start gap-4 rounded-[24px] p-5 text-left transition-all duration-300 ${
                    ativo
                      ? "bg-ink text-paper shadow-[0_24px_60px_-28px_rgb(15_30_54/0.55)]"
                      : "glass text-ink hover:-translate-y-0.5"
                  }`}
                >
                  <span
                    className={`flex size-11 flex-none items-center justify-center rounded-2xl ${
                      ativo ? "bg-paper/15" : "bg-surface-2 text-azul"
                    }`}
                  >
                    <Icone className="size-5" aria-hidden="true" />
                  </span>
                  <span className="flex flex-col gap-1">
                    <span className="text-[21px] font-semibold tracking-[-0.02em]">{titulo}</span>
                    <span className={`text-[15px] leading-[1.45] ${ativo ? "text-paper/75" : "text-muted"}`}>{texto}</span>
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      <div
        key={lado}
        role="tabpanel"
        id={`painel-${lado}`}
        aria-labelledby={`aba-${lado}`}
        className="animate-[servico-entra_.45s_ease-out]"
      >
        {lado === "front-end" ? <FrontEndPanel /> : <BackEndPanel />}
      </div>
    </>
  );
}
