import type { CategoriaSlug } from "./categorias";
import type { Mock } from "./projects";

/**
 * Nichos da página Projetos. Cada nicho mostra projetos reais e conceitos de interface.
 * - "Em produção" e "Em construção": projetos reais, com estudo de caso.
 * - "Conceito": tela desenhada para mostrar o tipo de produto, com marca e dados fictícios.
 */

export type ItemGaleria = {
  titulo: string;
  para: string;
  status: "Em produção" | "Em construção" | "Conceito";
  /** "web" usa moldura de navegador; "cena" é uma imagem já composta (apps). */
  formato: "web" | "cena" | "mock";
  imagem?: string;
  /** Versão para o tema escuro, quando existir. */
  imagemEscura?: string;
  mock?: Mock;
  projeto?: string;
};

export type Nicho = {
  slug: CategoriaSlug;
  titulo: string;
  /** Uma frase para o card da página inicial. */
  resumo: string;
  /** Públicos e usuários atendidos, mostrados no card da página inicial. */
  publicos: string[];
  /** Texto do botão do card da página inicial. */
  ver: string;
  texto: string[];
  aplicacoes: string[];
  contato: string;
  galeria: ItemGaleria[];
};

export const nichos: Nicho[] = [
  {
    slug: "dashboards",
    titulo: "Dashboards.",
    resumo: "Os números da operação reunidos num só painel, atualizados sem planilha.",
    publicos: ["Clubes e parques", "Pequenas e médias empresas", "Financeiro", "Atendimento"],
    ver: "Ver dashboards",
    texto: [
      "Todo negócio gera dados o dia inteiro: vendas, atendimentos, notas fiscais, estoque, acessos. Quando eles ficam espalhados em sistemas e planilhas, a decisão é tomada no escuro.",
      "Um dashboard organiza e estrutura esses dados num só lugar e transforma números soltos em controle. O mesmo princípio serve à diretoria de um clube, ao financeiro de uma pequena empresa e ao gestor de uma central de atendimento, em operações B2B ou B2C.",
    ],
    aplicacoes: [
      "Gestão financeira e fluxo de caixa",
      "Painel fiscal com notas emitidas e tributos",
      "Atendimento, tempo de resposta e satisfação",
      "Receita, vendas e metas por unidade",
    ],
    contato: "Falar sobre um dashboard",
    galeria: [
      {
        titulo: "Gestão de clubes e parques",
        para: "Diretoria de grandes clubes",
        status: "Em produção",
        formato: "web",
        imagem: "/conceitos/tatico-claro.webp",
        imagemEscura: "/conceitos/tatico-escuro.webp",
        projeto: "dashboard-tatico",
      },
      { titulo: "Gestão financeira", para: "Pequenas e médias empresas", status: "Conceito", formato: "web", imagem: "/conceitos/dash-financeiro.webp" },
      { titulo: "Painel fiscal", para: "Empresas e contadores", status: "Conceito", formato: "web", imagem: "/conceitos/dash-fiscal.webp" },
      { titulo: "Central de atendimento", para: "Equipes de WhatsApp e vendas", status: "Conceito", formato: "web", imagem: "/conceitos/dash-atendimento.webp" },
    ],
  },
  {
    slug: "erps",
    titulo: "Sistemas e ERPs.",
    resumo: "Vendas, estoque, agenda, financeiro e fiscal com as regras do seu negócio.",
    publicos: ["Varejo", "Clínicas", "Restaurantes", "Prestadores de serviço"],
    ver: "Ver sistemas",
    texto: [
      "Quando a empresa cresce, planilhas e ferramentas soltas viram retrabalho: o mesmo dado digitado três vezes, o estoque que não bate, a nota que ninguém emitiu.",
      "Um sistema sob medida reúne vendas, estoque, financeiro, agenda e fiscal com as regras do seu negócio, e cada pessoa vê o que precisa. Pode ser um ERP completo ou uma ferramenta enxuta para um processo que hoje trava a operação.",
    ],
    aplicacoes: [
      "Frente de caixa com estoque e NFC-e",
      "Agenda, confirmações e prontuário",
      "Emissão automática de notas fiscais",
      "Portais para clientes e fornecedores",
    ],
    contato: "Falar sobre um sistema",
    galeria: [
      { titulo: "Frente de caixa e estoque", para: "Cafés, padarias e varejo", status: "Conceito", formato: "web", imagem: "/conceitos/sis-pdv.webp" },
      { titulo: "Agenda de clínica", para: "Clínicas e consultórios", status: "Conceito", formato: "web", imagem: "/conceitos/sis-agenda.webp" },
    ],
  },
  {
    slug: "aplicativos",
    titulo: "Aplicativos.",
    resumo: "Um canal direto com o cliente, no celular, com notificações e pagamento.",
    publicos: ["Restaurantes", "Clubes e eventos", "Educação", "Saúde"],
    ver: "Ver aplicativos",
    texto: [
      "Um aplicativo coloca a sua empresa no celular do cliente. É o canal direto que não depende de anúncio nem de marketplace, com notificações que trazem o cliente de volta.",
      "Pode ser o delivery próprio de um restaurante, sem taxa de app, a carteira digital de um clube que dispensa dinheiro e fila, ou uma ferramenta de treino e estudo. Sempre conectado à mesma API do sistema web.",
    ],
    aplicacoes: [
      "Delivery próprio com rastreio e Pix",
      "Pagamento por aproximação (NFC) em clubes e eventos",
      "Educação e treino com acompanhamento",
      "Fidelidade, cashback e agendamento",
    ],
    contato: "Falar sobre um aplicativo",
    galeria: [
      { titulo: "Simulador clínico", para: "Estudantes de Medicina", status: "Em produção", formato: "cena", imagem: "/conceitos/app-praxis.webp", projeto: "praxis" },
      { titulo: "Delivery próprio", para: "Restaurantes e hamburguerias", status: "Conceito", formato: "cena", imagem: "/conceitos/app-delivery.webp" },
      { titulo: "Carteira NFC", para: "Clubes, parques e eventos", status: "Conceito", formato: "cena", imagem: "/conceitos/app-nfc.webp" },
    ],
  },
  {
    slug: "saas",
    titulo: "SaaS.",
    resumo: "Produtos por assinatura, com planos, cobrança recorrente e métricas de uso.",
    publicos: ["Startups", "Empresas B2B", "Software houses"],
    ver: "Ver SaaS",
    texto: [
      "Um SaaS transforma um processo que muitas empresas repetem em um produto vendido por assinatura. Cada cliente paga todo mês, entra pelo navegador e recebe as melhorias sem instalar nada.",
      "Construir um SaaS vai além das telas: planos e cobrança recorrente, isolamento dos dados de cada cliente, permissões, métricas de uso e uma página de preços que converte. Já apresentei e implantei produtos SaaS, do primeiro contato ao sistema rodando no cliente.",
    ],
    aplicacoes: [
      "Planos, cobrança recorrente e recuperação de pagamento",
      "Multiempresa, com os dados de cada cliente isolados",
      "Métricas de uso, retenção e funil de conversão",
      "Página de preços, teste grátis e onboarding",
    ],
    contato: "Falar sobre um SaaS",
    galeria: [
      { titulo: "Product analytics", para: "Times de produto", status: "Conceito", formato: "web", imagem: "/conceitos/saas-analytics.webp" },
      { titulo: "Gestão de assinaturas", para: "Empresas com receita recorrente", status: "Conceito", formato: "web", imagem: "/conceitos/saas-assinaturas.webp" },
      { titulo: "E-mail marketing", para: "Lojas e e-commerces", status: "Conceito", formato: "web", imagem: "/conceitos/saas-campanhas.webp" },
      { titulo: "Planos e preços", para: "Cardápio digital para restaurantes", status: "Conceito", formato: "web", imagem: "/conceitos/saas-precos.webp" },
    ],
  },
  {
    slug: "landing-pages",
    titulo: "Landing pages e sites.",
    resumo: "Páginas rápidas, feitas para transformar visita em contato.",
    publicos: ["Clínicas", "Restaurantes", "Escritórios", "Lançamentos"],
    ver: "Ver landing pages",
    texto: [
      "O site é onde o cliente decide se confia na sua empresa. A landing page é onde ele decide se vai chamar você agora ou fechar a aba.",
      "Cada página tem um objetivo só e é construída em volta dele: texto que fala da dor de quem lê, prova social, carregamento rápido no celular e cada clique medido. Serve tanto para a clínica que vende para pessoas quanto para o escritório que vende para empresas.",
    ],
    aplicacoes: [
      "Captação de pacientes e agendamento",
      "Cardápio e pedido direto, sem marketplace",
      "Sites institucionais B2B com área do cliente",
      "SEO local para aparecer no Google",
    ],
    contato: "Falar sobre uma landing page",
    galeria: [
      { titulo: "Clínica de estética", para: "Saúde e beleza", status: "Conceito", formato: "web", imagem: "/conceitos/lp-clinica.webp" },
      { titulo: "Hamburgueria com delivery", para: "Restaurantes", status: "Conceito", formato: "web", imagem: "/conceitos/lp-burger.webp" },
      { titulo: "Escritório de contabilidade", para: "Serviços B2B", status: "Conceito", formato: "web", imagem: "/conceitos/lp-contabil.webp" },
    ],
  },
  {
    slug: "automacoes",
    titulo: "Automações e IA.",
    resumo: "Rotinas e agentes de IA que tiram horas de trabalho manual da equipe.",
    publicos: ["Comercial", "Atendimento", "Operações"],
    ver: "Ver automações",
    texto: [
      "Boa parte do dia de uma equipe vai para tarefas repetitivas: responder as mesmas perguntas, cobrar, lembrar, copiar dados de um sistema para outro.",
      "Automações e agentes de IA assumem esse trabalho com regras claras, do lead que chega qualificado ao follow-up que sai no dia certo, e devolvem esse tempo para o que gera resultado.",
    ],
    aplicacoes: [
      "Funil de vendas com prospecção automática",
      "Agente de IA no WhatsApp para atender e agendar",
      "Rotinas internas que levavam dias",
      "Integração entre sistemas, planilhas e CRM",
    ],
    contato: "Falar sobre automação",
    galeria: [
      { titulo: "Funil de vendas com IA", para: "Equipes comerciais", status: "Conceito", formato: "web", imagem: "/conceitos/sis-crm.webp" },
      { titulo: "Montagem de álbuns", para: "Empresas de formatura", status: "Em produção", formato: "web", imagem: "/conceitos/app-albuns.webp", projeto: "montador-de-albuns" },
    ],
  },
];

export function getNicho(slug: string) {
  return nichos.find((n) => n.slug === slug);
}
