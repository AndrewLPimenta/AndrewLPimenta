export const pessoas = [
  {
    titulo: "Com gestores",
    texto:
      "Na Multiclubes, traduzo a pergunta de quem decide num painel que responde, e explico decisões técnicas sem jargão.",
  },
  {
    titulo: "Com especialistas",
    texto: "Num simulador clínico, trabalho com médicas para transformar protocolo clínico em regra que o sistema consegue verificar.",
  },
  {
    titulo: "Com quem opera",
    texto:
      "Na automação de álbuns, ouço a equipe que monta e meço o que ela considera certo, em vez de impor o que eu acho.",
  },
  {
    titulo: "Com clientes",
    texto: "Já apresentei e implantei produtos SaaS, do primeiro contato ao sistema funcionando no dia a dia do cliente.",
  },
];

export const softSkills = [
  {
    titulo: "Comunicação clara",
    texto: "Escrevo e falo para quem vai ler: tecnicamente com o time, em linguagem de negócio com quem decide.",
  },
  { titulo: "Dono do problema", texto: "Acompanho o que entreguei depois do deploy. Se quebrou, é meu até estar resolvido." },
  { titulo: "Prioridade e foco", texto: "Sei dizer não, ou ainda não, para entregar primeiro o que tem mais valor." },
  {
    titulo: "Feedback nos dois sentidos",
    texto: "Peço revisão cedo, recebo crítica sem levar para o pessoal e dou retorno com respeito e exemplo concreto.",
  },
  {
    titulo: "Aprendizado rápido",
    texto: "Entro em domínios novos, como saúde, fiscal ou gestão de clubes, e aprendo o vocabulário de quem trabalha neles.",
  },
  {
    titulo: "Visão de negócio",
    texto: "Antes da solução técnica, pergunto quanto aquela dor custa, para quem e quantas vezes por mês.",
  },
];

export type Skill = { nome: string; principal?: boolean };

export const hardSkills: { grupo: string; itens: Skill[] }[] = [
  {
    grupo: "Backend",
    itens: [
      { nome: "C#", principal: true },
      { nome: ".NET", principal: true },
      { nome: "ASP.NET Core", principal: true },
      { nome: "Entity Framework Core" },
      { nome: "LINQ" },
      { nome: "Node.js", principal: true },
      { nome: "TypeScript", principal: true },
    ],
  },
  {
    grupo: "Frontend",
    itens: [
      { nome: "React" },
      { nome: "Next.js", principal: true },
      { nome: "Tailwind CSS" },
      { nome: "shadcn/ui" },
      { nome: "Acessibilidade" },
    ],
  },
  { grupo: "Mobile", itens: [{ nome: "Apps iOS" }, { nome: "TestFlight" }, { nome: "Login com Google e Apple" }] },
  {
    grupo: "Dados",
    itens: [
      { nome: "PostgreSQL", principal: true },
      { nome: "SQL" },
      { nome: "Supabase" },
      { nome: "Modelagem de dados" },
      { nome: "Row Level Security" },
    ],
  },
  {
    grupo: "Integrações e mensageria",
    itens: [
      { nome: "APIs REST" },
      { nome: "RabbitMQ" },
      { nome: "Arquitetura orientada a eventos" },
      { nome: "Open Finance" },
      { nome: "Autenticação com JWT" },
    ],
  },
  {
    grupo: "Infra e entrega",
    itens: [
      { nome: "Docker", principal: true },
      { nome: "Azure" },
      { nome: "Azure DevOps" },
      { nome: "CI/CD" },
      { nome: "Microsserviços" },
    ],
  },
  {
    grupo: "Qualidade",
    itens: [
      { nome: "Testes automatizados" },
      { nome: "Testes de regra de negócio no banco" },
      { nome: "Code review" },
      { nome: "SonarQube" },
    ],
  },
  {
    grupo: "Processo",
    itens: [
      { nome: "Casos de uso" },
      { nome: "Histórias de usuário" },
      { nome: "Critérios de aceite" },
      { nome: "Scrum" },
      { nome: "Orquestração de agentes de IA" },
    ],
  },
];

/** Capítulos da carreira, do começo até hoje. */
export const trajetoria = [
  {
    marco: "2021",
    titulo: "Sites e landing pages",
    texto:
      "Comecei com sites e landing pages para clientes reais. Ali aprendi a primeira regra do ofício: software bom é o que resolve o problema de quem paga por ele.",
  },
  {
    marco: "Sistemas sob medida",
    titulo: "De páginas a sistemas inteiros",
    texto:
      "Dezenas de projetos depois, vieram os sistemas: painéis, ferramentas internas, APIs e integrações, dos mais simples aos mais complexos.",
  },
  {
    marco: "Automação",
    titulo: "Automação medida por gabarito",
    texto:
      "Uma automação que monta centenas de álbuns de formatura sozinha, medindo cada regra contra um gabarito de 87 álbuns feitos à mão.",
  },
  {
    marco: "Produto",
    titulo: "Produto com regra crítica",
    texto:
      "Um app para estudantes de Medicina treinarem atendimento de emergência, com API em .NET e as regras do produto protegidas por 126 testes.",
  },
  {
    marco: "Hoje",
    titulo: "Engenheiro de Software na Multiclubes",
    texto:
      "C#/.NET no back-end, Next.js no front-end e painéis de gestão usados por grandes clubes e parques do país. Em paralelo, curso Sistemas de Informação.",
    atual: true,
  },
];
